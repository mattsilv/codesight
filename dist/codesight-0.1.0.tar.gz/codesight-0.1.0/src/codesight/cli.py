"""Command-line interface for CodeSight."""
import click
import pyperclip
from pathlib import Path
from .config import load_config, auto_detect_project_type
from .collate import gather_and_collate

@click.command()
@click.option('--root', default='.', help='Root folder to scan.')
@click.option('--output', default='codesight_output.txt', help='Output file path.')
@click.option('--type', 'project_type', default=None, help='Force a project type (e.g. python, javascript).')
@click.option('--user-config', default=None, help='Path to user config file.')
@click.option('--copy-to-clipboard', is_flag=True, help='Copy the final result to the clipboard.')
def codesight(root, output, project_type, user_config, copy_to_clipboard):
    """CodeSight: Simple LLM-friendly code collation with minimal config required."""
    root_path = Path(root).resolve()

    # Load base config
    config = load_config(user_config)

    # Auto-detect project type if not supplied by user
    if not project_type:
        project_type = auto_detect_project_type(root_path)
        click.echo(f"Detected project type: {project_type}")

    # Merge template if project type is known
    if project_type in config["templates"]:
        config.update(config["templates"][project_type])

    # Collate
    final_text = gather_and_collate(root_path, config)

    # Write output
    with open(output, 'w', encoding='utf-8') as f:
        f.write(final_text)
    click.echo(f"Output written to {output}")

    # Optional copy to clipboard
    if copy_to_clipboard:
        try:
            pyperclip.copy(final_text)
            click.echo("Copied output to clipboard.")
        except pyperclip.PyperclipException:
            click.echo("Clipboard copy not supported on this system.")

def main():
    """Entry point for the CLI."""
    codesight() 