"""Core file gathering and collation logic."""
import ast
from pathlib import Path
from typing import List, Set
import fnmatch

def parse_gitignore(root_folder: Path) -> List[str]:
    """Parse .gitignore patterns from the root folder."""
    gitignore_path = root_folder / '.gitignore'
    if not gitignore_path.exists():
        return []
    
    with open(gitignore_path, 'r') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

def should_ignore(path: Path, gitignore_patterns: List[str], config: dict) -> bool:
    """Check if a file should be ignored based on patterns and config."""
    rel_path = str(path)
    
    # Check gitignore patterns
    for pattern in gitignore_patterns:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    
    # Check config exclusions
    if path.name in config['exclude_files']:
        return True
    if path.suffix in config.get('exclude_extensions', []):
        return True
    for pattern in config['exclude_patterns']:
        if pattern.startswith('**/'):
            # Handle **/ patterns by checking against the full path
            if fnmatch.fnmatch(rel_path, pattern[3:]):
                return True
        else:
            if fnmatch.fnmatch(rel_path, pattern):
                return True
            
    return False

def truncate_large_literals(node: ast.AST, max_elements: int = 5) -> ast.AST:
    """Truncate large lists, sets, dicts in Python AST."""
    if isinstance(node, (ast.List, ast.Set, ast.Dict)):
        if isinstance(node, ast.Dict):
            if len(node.keys) > max_elements:
                node.keys = node.keys[:max_elements]
                node.values = node.values[:max_elements]
        else:
            if len(node.elts) > max_elements:
                node.elts = node.elts[:max_elements]
    for child in ast.iter_child_nodes(node):
        truncate_large_literals(child, max_elements)
    return node

def process_python_file(content: str, max_elements: int) -> str:
    """Process Python file content, truncating large literals."""
    try:
        tree = ast.parse(content)
        modified_tree = truncate_large_literals(tree, max_elements)
        return ast.unparse(modified_tree)
    except:
        return content  # Return original if parsing fails

def gather_and_collate(root_folder: Path, config: dict) -> str:
    """Gather and collate files based on configuration."""
    gitignore_patterns = parse_gitignore(root_folder)
    collected_files = []
    
    for path in root_folder.rglob('*'):
        if not path.is_file():
            continue
            
        if should_ignore(path, gitignore_patterns, config):
            continue
            
        if path.suffix in config['include_extensions'] or str(path.name) in config['include_files']:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Process Python files if needed
            if path.suffix == '.py' and config['truncate_py_literals']:
                content = process_python_file(content, config['truncate_py_literals'])
                
            relative_path = path.relative_to(root_folder)
            collected_files.append(f"### File: {relative_path}\n\n```{path.suffix[1:]}\n{content}\n```\n\n")
            
    return "".join(collected_files) 