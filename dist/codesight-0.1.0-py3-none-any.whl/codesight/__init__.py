"""CodeSight: Simple LLM-friendly code collation tool."""

__version__ = "0.1.0" 