"""Configuration management for CodeSight."""
from pathlib import Path
import toml

DEFAULT_CONFIG = {
    "include_extensions": [".py", ".md", ".rst", ".sql", ".toml"],
    "exclude_files": [".gitignore"],  # Always exclude .gitignore from final output
    "include_files": ["pyproject.toml", "README.md"],
    "exclude_patterns": [],
    "truncate_py_literals": 5,
    "templates": {
        "python": {
            "exclude_extensions": [".csv", ".pkl", ".db"],
        },
        "javascript": {
            "exclude_extensions": [".map", ".lock"],
        }
    }
}

def parse_user_config(config_path: str) -> dict:
    """Parse user configuration file."""
    path = Path(config_path)
    if path.suffix == '.toml':
        return toml.load(path)
    raise ValueError(f"Unsupported config file format: {path.suffix}")

def merge_configs(base: dict, override: dict) -> dict:
    """Merge override config into base config."""
    for key, value in override.items():
        if isinstance(value, dict) and key in base:
            merge_configs(base[key], value)
        else:
            base[key] = value
    return base

def load_config(user_config_path=None) -> dict:
    """Load default config and merge in user overrides if provided."""
    config = dict(DEFAULT_CONFIG)
    if user_config_path:
        user_overrides = parse_user_config(user_config_path)
        merge_configs(config, user_overrides)
    return config

def auto_detect_project_type(root_folder: Path) -> str:
    """Detect Python vs. JavaScript or default to unopinionated if ambiguous."""
    if (root_folder / "pyproject.toml").exists():
        return "python"
    elif (root_folder / "package.json").exists():
        return "javascript"
    return "unopinionated" 